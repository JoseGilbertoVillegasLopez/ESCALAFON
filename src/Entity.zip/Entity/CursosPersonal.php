<?php

namespace App\Entity;

use App\Repository\CursosPersonalRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CursosPersonalRepository::class)]
class CursosPersonal
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    /**
     * @var Collection<int, Cursos>
     */
    #[ORM\ManyToMany(targetEntity: Cursos::class)]
    private Collection $cursos;

    #[ORM\ManyToOne(inversedBy: 'cursosPersonal')]
    private ?InformacionPersonal $informacionPersonal = null;

    public function __construct()
    {
        $this->cursos = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection<int, Cursos>
     */
    public function getCursos(): Collection
    {
        return $this->cursos;
    }

    public function addCurso(Cursos $curso): static
    {
        if (!$this->cursos->contains($curso)) {
            $this->cursos->add($curso);
        }

        return $this;
    }

    public function removeCurso(Cursos $curso): static
    {
        $this->cursos->removeElement($curso);

        return $this;
    }

    public function getInformacionPersonal(): ?InformacionPersonal
    {
        return $this->informacionPersonal;
    }

    public function setInformacionPersonal(?InformacionPersonal $informacionPersonal): static
    {
        $this->informacionPersonal = $informacionPersonal;

        return $this;
    }
}
