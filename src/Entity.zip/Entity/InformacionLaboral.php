<?php

namespace App\Entity;

use App\Repository\InformacionLaboralRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: InformacionLaboralRepository::class)]
class InformacionLaboral
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $numeroAfiliado = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTime $fechaIncorporacion = null;

    #[ORM\Column]
    private ?bool $tipoPlaza = null;

    #[ORM\Column(length: 255)]
    private ?string $turnoActual = null;

    #[ORM\Column(length: 255)]
    private ?string $jornada = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Categoria $categoriaActual = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Puesto $puestoActual = null;

    /**
     * @var Collection<int, HistorialAscenso>
     */
    #[ORM\OneToMany(targetEntity: HistorialAscenso::class, mappedBy: 'informacionLaboral')]
    private Collection $historialAscensos;

    /**
     * @var Collection<int, HistorialSanciones>
     */
    #[ORM\OneToMany(targetEntity: HistorialSanciones::class, mappedBy: 'informacionLaboral')]
    private Collection $historialSanciones;

    #[ORM\OneToOne(mappedBy: 'informacionLaboral', targetEntity: InformacionPersonal::class)]
    private ?InformacionPersonal $informacionPersonal = null;

    public function __construct()
    {
        $this->historialAscensos = new ArrayCollection();
        $this->historialSanciones = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumeroAfiliado(): ?string
    {
        return $this->numeroAfiliado;
    }

    public function setNumeroAfiliado(string $numeroAfiliado): static
    {
        $this->numeroAfiliado = $numeroAfiliado;

        return $this;
    }

    public function getFechaIncorporacion(): ?\DateTime
    {
        return $this->fechaIncorporacion;
    }

    public function setFechaIncorporacion(\DateTime $fechaIncorporacion): static
    {
        $this->fechaIncorporacion = $fechaIncorporacion;

        return $this;
    }

    public function isTipoPlaza(): ?bool
    {
        return $this->tipoPlaza;
    }

    public function setTipoPlaza(bool $tipoPlaza): static
    {
        $this->tipoPlaza = $tipoPlaza;

        return $this;
    }

    public function getTurnoActual(): ?string
    {
        return $this->turnoActual;
    }

    public function setTurnoActual(string $turnoActual): static
    {
        $this->turnoActual = $turnoActual;

        return $this;
    }

    public function getJornada(): ?string
    {
        return $this->jornada;
    }

    public function setJornada(string $jornada): static
    {
        $this->jornada = $jornada;

        return $this;
    }

    public function getCategoriaActual(): ?Categoria
    {
        return $this->categoriaActual;
    }

    public function setCategoriaActual(?Categoria $categoriaActual): static
    {
        $this->categoriaActual = $categoriaActual;

        return $this;
    }

    public function getPuestoActual(): ?Puesto
    {
        return $this->puestoActual;
    }

    public function setPuestoActual(?Puesto $puestoActual): static
    {
        $this->puestoActual = $puestoActual;

        return $this;
    }

    /**
     * @return Collection<int, HistorialAscenso>
     */
    public function getHistorialAscensos(): Collection
    {
        return $this->historialAscensos;
    }

    public function addHistorialAscenso(HistorialAscenso $historialAscenso): static
    {
        if (!$this->historialAscensos->contains($historialAscenso)) {
            $this->historialAscensos->add($historialAscenso);
            $historialAscenso->setInformacionLaboral($this);
        }

        return $this;
    }

    public function removeHistorialAscenso(HistorialAscenso $historialAscenso): static
    {
        if ($this->historialAscensos->removeElement($historialAscenso)) {
            // set the owning side to null (unless already changed)
            if ($historialAscenso->getInformacionLaboral() === $this) {
                $historialAscenso->setInformacionLaboral(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, HistorialSanciones>
     */
    public function getHistorialSanciones(): Collection
    {
        return $this->historialSanciones;
    }

    public function addHistorialSancione(HistorialSanciones $historialSancione): static
    {
        if (!$this->historialSanciones->contains($historialSancione)) {
            $this->historialSanciones->add($historialSancione);
            $historialSancione->setInformacionLaboral($this);
        }

        return $this;
    }

    public function removeHistorialSancione(HistorialSanciones $historialSancione): static
    {
        if ($this->historialSanciones->removeElement($historialSancione)) {
            // set the owning side to null (unless already changed)
            if ($historialSancione->getInformacionLaboral() === $this) {
                $historialSancione->setInformacionLaboral(null);
            }
        }

        return $this;
    }

    public function getInformacionPersonal(): ?InformacionPersonal
    {
        return $this->informacionPersonal;
    }

    public function setInformacionPersonal(?InformacionPersonal $informacionPersonal): static
    {
        // unset the owning side of the relation if necessary
        if ($informacionPersonal === null && $this->informacionPersonal !== null) {
            $this->informacionPersonal->setInformacionLaboral(null);
        }

        // set the owning side of the relation if necessary
        if ($informacionPersonal !== null && $informacionPersonal->getInformacionLaboral() !== $this) {
            $informacionPersonal->setInformacionLaboral($this);
        }

        $this->informacionPersonal = $informacionPersonal;

        return $this;
    }
}
