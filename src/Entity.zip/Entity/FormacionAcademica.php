<?php

namespace App\Entity;

use App\Repository\FormacionAcademicaRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: FormacionAcademicaRepository::class)]
class FormacionAcademica
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $escolaridadTerminada = null;

    #[ORM\Column(length: 255)]
    private ?string $certificado = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEscolaridadTerminada(): ?string
    {
        return $this->escolaridadTerminada;
    }

    public function setEscolaridadTerminada(string $escolaridadTerminada): static
    {
        $this->escolaridadTerminada = $escolaridadTerminada;

        return $this;
    }

    public function getCertificado(): ?string
    {
        return $this->certificado;
    }

    public function setCertificado(string $certificado): static
    {
        $this->certificado = $certificado;

        return $this;
    }
}
