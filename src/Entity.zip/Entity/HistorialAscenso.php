<?php

namespace App\Entity;

use App\Repository\HistorialAscensoRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: HistorialAscensoRepository::class)]
class HistorialAscenso
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTime $fecha = null;

    #[ORM\Column(length: 255)]
    private ?string $puestoAnterior = null;

    #[ORM\Column(length: 255)]
    private ?string $puestoActual = null;

    #[ORM\ManyToOne(inversedBy: 'historialAscensos')]
    private ?InformacionLaboral $informacionLaboral = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFecha(): ?\DateTime
    {
        return $this->fecha;
    }

    public function setFecha(\DateTime $fecha): static
    {
        $this->fecha = $fecha;

        return $this;
    }

    public function getPuestoAnterior(): ?string
    {
        return $this->puestoAnterior;
    }

    public function setPuestoAnterior(string $puestoAnterior): static
    {
        $this->puestoAnterior = $puestoAnterior;

        return $this;
    }

    public function getPuestoActual(): ?string
    {
        return $this->puestoActual;
    }

    public function setPuestoActual(string $puestoActual): static
    {
        $this->puestoActual = $puestoActual;

        return $this;
    }

    public function getInformacionLaboral(): ?InformacionLaboral
    {
        return $this->informacionLaboral;
    }

    public function setInformacionLaboral(?InformacionLaboral $informacionLaboral): static
    {
        $this->informacionLaboral = $informacionLaboral;

        return $this;
    }
}
